package com.example.date_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
