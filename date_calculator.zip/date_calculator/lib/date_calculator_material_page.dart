import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:date_calculator/theme/theme_provider.dart';


class DateCalculatorMaterialPage extends StatefulWidget {
  const DateCalculatorMaterialPage({super.key});

  @override
  State<DateCalculatorMaterialPage> createState() => _DateCalculatorMaterialPageState();
}

class _DateCalculatorMaterialPageState extends State<DateCalculatorMaterialPage> {
  
  final _dayController = TextEditingController();
  int _selectedYear = 2024;
  String _resultDate = '';
  String _weekOfYear = '';
  String _isLeapYear = '';

  void _calculateDate() {
    final int dayOfYear = int.tryParse(_dayController.text) ?? 0;
    final int year = int.tryParse(_selectedYear.toString()) ?? 0;

    if (dayOfYear <= 0 || dayOfYear > 366 || year <= 0) {
      setState(() {
        _resultDate = 'Invalid Input';
        _weekOfYear = 'Invalid Input';
        _isLeapYear = 'Invalid Input';
      });
      return;
    }
    final DateTime startOfYear = DateTime(year, 1, 1);
    final DateTime targetDate = startOfYear.add(Duration(days: dayOfYear - 1));
    final DateFormat dateFormat = DateFormat('dd/MM/yyyy');

    final int weekOfYear = ((targetDate.dayOfYear + targetDate.weekday - 1) ~/ 7) + 1;
    final bool leapYear = isLeapYear(year);

    setState(() {
      _resultDate = dateFormat.format(targetDate);
      _weekOfYear = weekOfYear.toString();
      _isLeapYear = leapYear ? 'true' : 'false';
    });
  }

  bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      appBar: AppBar(
         backgroundColor: Theme.of(context).colorScheme.primary,
        elevation: 3,
        title: const Text("DATE CALCULATOR"),
        centerTitle: true,
        titleTextStyle:TextStyle(
          color: Theme.of(context).colorScheme.secondary,
          fontWeight: FontWeight.w900,
          fontSize: 40,
        ),
        
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: IconButton(
              splashColor: Theme.of(context).colorScheme.surface,
              onPressed: () {
                Provider.of<ThemeProvider>(context, listen: false).toggleTheme();
              }, 
              icon:Icon(
                Icons.dark_mode,
                color: Theme.of(context).colorScheme.secondary,
                ),
            ),
          ),
        ],
      ),
      body: Form(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: _dayController,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.bold
                  ),
                  decoration: InputDecoration(
                    hintText: "Please enter the Day",
                    hintStyle: TextStyle(
                      color:  Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.normal
                    ),
                    prefixIcon: const Icon(Icons.numbers),
                    prefixIconColor: Theme.of(context).colorScheme.primary,
                    filled: true,
                    fillColor: Theme.of(context).colorScheme.secondary,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Theme.of(context).colorScheme.primary,
                        width: 2.50,
                        style:BorderStyle.solid,
                        strokeAlign: BorderSide.strokeAlignOutside,
                      ),
                      borderRadius:const BorderRadius.all(
                        Radius.circular(100),
                      ),
                    ),
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Theme.of(context).colorScheme.primary,
                        width: 2.0,
                      ),
                    ),
                  ),
                  validator:(value){
                    int day= int.parse(value.toString());
                    if (day<1 || day>366){
                      return 'Please enter a valid Day';
                    }
                    return null;
                  },
                  keyboardType:const TextInputType.numberWithOptions(
                    decimal: false,
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  color: Theme.of(context).colorScheme.secondary,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.calendar_month,
                        color: Theme.of(context).colorScheme.primary,
                        ),
                      const SizedBox(width:5),
                      Text(
                        'Year',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.primary,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                        ),
                        const SizedBox(width: 15),
                      DropdownButton(
                      value: _selectedYear,
                      dropdownColor:Theme.of(context).colorScheme.secondary,
                      onChanged: (int? newValue) {
                        setState(() {
                          _selectedYear = newValue!;
                        });
                      },
                      items: [
                        for (int i = 1980; i <= 2030; i++)
                        DropdownMenuItem(
                        value: i,
                        child: Text(
                          '$i',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                            fontSize: 22,
                          )
                        ),
                        ),
                      ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                //Calculate Button
                ElevatedButton(
                onPressed: (){
                  _calculateDate();
                }, 
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor:Theme.of(context).colorScheme.secondary,
                    fixedSize:const Size(250, 40),
                  ),
                  child:Text(
                  "CALCULATE",
                  style: TextStyle(
                    fontSize: 22,
                    color: Theme.of(context).colorScheme.secondary,
                  ),
                  ),
              ),
              const SizedBox(height: 30),
                
              Text(
                    'Date: $_resultDate',
                    style:TextStyle(
                      fontSize: 22,
                      color: Theme.of(context).colorScheme.tertiary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
              Text(
                'Week of the Year: $_weekOfYear',
                style:TextStyle(
                  fontSize: 22,
                  color: Theme.of(context).colorScheme.tertiary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Leap Year: $_isLeapYear',
                style:TextStyle(
                  fontSize: 22,
                  color: Theme.of(context).colorScheme.tertiary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            
            ]
          )
        ),
      )
    );
  }
}


//Extension
extension DateTimeExtensions on DateTime {
  int get dayOfYear {
    final startOfYear = DateTime(year);
    return difference(startOfYear).inDays + 1;
  }

  static bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
  }
}