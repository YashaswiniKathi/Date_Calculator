import 'package:flutter/material.dart';

ThemeData lightmode = ThemeData(
  brightness: Brightness.light,
  colorScheme: const ColorScheme.light(
    surface: Color.fromRGBO(195, 191, 196, 1),
    primary: Color.fromARGB(255, 26, 20, 59),
    secondary: Colors.white,
    tertiary: Color.fromARGB(255, 26, 20, 59),
  )
);

ThemeData darkmode = ThemeData(
  brightness: Brightness.dark,
  colorScheme: const ColorScheme.dark(
    surface: Color.fromARGB(255, 34, 34, 34),
    primary: Color.fromARGB(255, 10, 10, 10),
    secondary: Colors.white,
    tertiary: Colors.white,
  )
);